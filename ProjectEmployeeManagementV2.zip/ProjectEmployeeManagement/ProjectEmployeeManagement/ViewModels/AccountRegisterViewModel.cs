﻿using Microsoft.AspNetCore.Mvc;
using ProjectEmployeeManagement.Models;
using System.ComponentModel.DataAnnotations;

namespace ProjectEmployeeManagement.ViewModels
    {
    public class AccountRegisterViewModel
        {
        [Required]
        [EmailAddress]
        [Remote(action: "IsEmailInUse", controller: "Account")]
        [GmailValidation(_email:"gmail.com",ErrorMessage = "Domain must be gmail.com")]
        public string EmailAddress { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("Password",ErrorMessage = "Password & Confirmation Password do not match")]
        public string ConfirmPassword { get; set;}
        }
    }
