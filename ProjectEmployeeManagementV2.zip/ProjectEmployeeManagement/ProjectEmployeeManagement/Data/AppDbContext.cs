﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProjectEmployeeManagement.Extensions;
//using ProjectEmployeeManagement.Extensions;

using ProjectEmployeeManagement.Models;
using System.Numerics;

namespace ProjectEmployeeManagement.Data
    {
    public class AppDbContext:IdentityDbContext<AppUser>
        {
        public AppDbContext(DbContextOptions<AppDbContext>options):base(options)
        {
            
        }
        public DbSet<Employee> Employee { get; set; }
      protected override void OnModelCreating( ModelBuilder modelBuilder )
            {
            base.OnModelCreating(modelBuilder );
            modelBuilder.SeedEmployee();
            }
        }
    
    
    }
