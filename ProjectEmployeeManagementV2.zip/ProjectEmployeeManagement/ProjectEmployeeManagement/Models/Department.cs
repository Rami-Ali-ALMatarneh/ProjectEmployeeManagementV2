﻿namespace ProjectEmployeeManagement.Models
    {
    public enum Department
        {
        SoftwareDevelopment,
        ITOperations,
        QualityAssurance,
        ProjectManagement,
        ITConsulting,
        ResearchAndDevelopment
        }
    }
