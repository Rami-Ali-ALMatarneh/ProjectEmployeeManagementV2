﻿using Microsoft.AspNetCore.Identity;

namespace ProjectEmployeeManagement.Models
    {
    public class AppUser:IdentityUser
        {
        }
    }
