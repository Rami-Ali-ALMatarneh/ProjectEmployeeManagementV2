﻿using System.ComponentModel.DataAnnotations;

namespace ProjectEmployeeManagement.Models
    {
    public class GmailValidationAttribute:ValidationAttribute
        {
        private readonly string _email;
        public GmailValidationAttribute( string _email )
            {
            this._email = _email;
            }
        public override bool IsValid( object? value )
            {
            string[] Domain = value.ToString().Split("@");
            return Domain[1].ToUpper()==_email.ToUpper();
            }
        }
    }
