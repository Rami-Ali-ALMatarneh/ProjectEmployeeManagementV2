﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ProjectEmployeeManagement.Models;
using ProjectEmployeeManagement.ViewModels;

namespace ProjectEmployeeManagement.Controllers
    {
    [AllowAnonymous]
    public class AccountController : Controller
        {
        private readonly UserManager<AppUser> userManager;
        private readonly SignInManager<AppUser> signInManager;
        public AccountController( UserManager<AppUser> userManager, SignInManager<AppUser> signInManager )
            {
            this.userManager = userManager;
            this.signInManager = signInManager;
    
            }
        public IActionResult Index()
            {
            return View();
            }
        [HttpGet]
        public IActionResult Register()
            {
            return View();
            }
        [HttpGet]
        public IActionResult Login()
            {
            return View();
            }
        [HttpPost]
        public async Task<IActionResult> Register( AccountRegisterViewModel model )
            {
            if (ModelState.IsValid)

                {
                var user = new AppUser
                    {
                    UserName = model.EmailAddress,
                    Email = model.EmailAddress,
                    };
                var result = await userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                    {
                    await signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("index", "home");

                    }
                foreach (var error in result.Errors)
                    {
                    ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
            return View(model);
            }
        public async Task<IActionResult> Logout()
            {
            await signInManager.SignOutAsync();
            return RedirectToAction("index", "home");
            }
        [HttpPost]
        public async Task<IActionResult> Login( LoginViewModel model, string returnUrl = null )
            {
            if (ModelState.IsValid)
                {
                var result = await signInManager.PasswordSignInAsync(model.EmailAddress, model.Password, model.RememberMe, false);
                if (result.Succeeded)
                    {
                    if (Url.IsLocalUrl(returnUrl) && !String.IsNullOrEmpty(returnUrl))
                        {
                        return LocalRedirect(returnUrl);
                        }
                    else
                        {
                        return RedirectToAction("index", "home");
                        }
                    }
                ModelState.AddModelError(String.Empty, "In valid Login.");
                }
            return View(model);

            }
        [AcceptVerbs("Get", "Post")]
        [AllowAnonymous]
        public async Task<IActionResult> IsEmailInUse( string email )
            {
            var user = await userManager.FindByEmailAsync(email);

            if (user == null)
                {
                return Json(true);
                }
            else
                {
                return Json($"Email {email} is already in use.");
                }


            }
        }
        }
