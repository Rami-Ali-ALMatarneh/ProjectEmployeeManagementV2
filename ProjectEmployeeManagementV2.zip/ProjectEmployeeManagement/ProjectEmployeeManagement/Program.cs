using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using ProjectEmployeeManagement.Data;
using ProjectEmployeeManagement.Models;

var builder = WebApplication.CreateBuilder(args);


#region ConfigureServices
//1- Add MVC Services
builder.Services.AddMvc(options => {
    options.EnableEndpointRouting = false;
    //add Authorization policy
    var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
    options.Filters.Add(new AuthorizeFilter(policy));

}).AddXmlSerializerFormatters();
//3- dependency injection
//builder.Services.AddSingleton<IEmployeeRepository, MockEmployeeRepository>();
//4- DbContextPool
builder.Services.AddDbContextPool<AppDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("EmployeeConnectionStrings")));
//6- IdentityDbContext
builder.Services.AddIdentity<AppUser, IdentityRole>().AddEntityFrameworkStores<AppDbContext>();
////5- dependency injection  --> Database   
builder.Services.AddScoped<IEmployeeRepository,SqlEmployeeRepository>();
#endregion




var app = builder.Build();


#region Middleware
//2- Add Middleware Mvc
if (app.Environment.IsDevelopment())
    {
    app.UseDeveloperExceptionPage();
    }
/////////////////////////////////

app.UseStatusCodePagesWithRedirects("/Error/{0}");
/////////////////////////////////
app.UseExceptionHandler("/ErrorException");
/////////////////////////////////

app.UseRouting();
app.UseStaticFiles();
app.UseAuthentication();
app.UseMvc(Route =>
{
    Route.MapRoute(name: "default", template: "{controller=home}/{action=index}/{id?}");
});
//app.UseMvcWithDefaultRoute();
app.Run();
#endregion
/////////////////////////////////
